#ifndef __PAPER_WINDOW_H__
#define __PAPER_WINDOW_H__
#include "paper_define.h"
#include <windows.h>
//����д����

struct paper_window
{
	void* hWnd;			//���ھ��
};


struct paper_window* paper_window_create(const wchar_t* szTitle, WNDPROC proc, int x, int y, int width, int height);

void paper_window_show(struct paper_window* window);

#endif	//__PAPER_WINDOW_H__

