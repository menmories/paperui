﻿// paperui.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
/*
* 目标：跨平台gui
*/
#include <iostream>
#include "paper_window.h"
#include <windows.h>
#include <tchar.h>
#include <gdiplus.h>
//gdi+来绘制一张图片
using namespace Gdiplus;

#pragma comment(lib, "gdiplus.lib")

//窗口回调函数，在这里处理窗口消息
LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
ULONG_PTR token;
Gdiplus::GdiplusStartupInput input;
int main(int argc, char** argv)
{
    Gdiplus::GdiplusStartup(&token, &input, nullptr);
    struct paper_window* window = paper_window_create(TEXT("你好呀"), WndProc, 100, 100, 1000, 600);
    paper_window_show(window);
    //窗口消息事件循环
    MSG msg = { 0 };
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);      //WM_QUIT
    }
    return (int)msg.wParam;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == WM_PAINT)   //WM_PAINT	//绘图消息，告诉我们窗口应该绘图了
    {
        PAINTSTRUCT ps = { 0 };
        HDC hdc = ::BeginPaint(hWnd, &ps);
        //在这里加入绘图代码
        Graphics grx(hdc);
        grx.Clear(Color(0xffffffff));
        Image image(L"E:\\GitHub\\paperui\\paperui\\QQ图片20220327005530.png");
        grx.DrawImage(&image, 100, 0, 400, 520);

        std::wstring str = L"Hello world!";
        Font font(L"Microsoft Yahei", 14.0f);

        SolidBrush solidBrush(0xffff0000);        //a rgb
        grx.DrawString(str.c_str(), str.length(), &font, PointF(110, 0), &solidBrush);

        ::EndPaint(hWnd, &ps);
        return FALSE;
    }
    if (uMsg == WM_CLOSE)
    {
        DestroyWindow(hWnd);
        return FALSE;
    }
    if (uMsg == WM_DESTROY)
    {
        PostQuitMessage(0);
        return FALSE;
    }
    return ::DefWindowProc(hWnd, uMsg, wParam, lParam);     //默认处理窗口回调函数
}