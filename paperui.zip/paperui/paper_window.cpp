#include "paper_window.h"
#include <Windows.h>
#include <stdio.h>

#define DEFAULT_WINDOW_CLASSNAME TEXT("PAPER_WINDOW")

struct paper_window* paper_window_create(const wchar_t* szTitle, WNDPROC proc, int x, int y, int width, int height)
{
	WNDCLASS wc = { 0 };
	wc.style = CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hIcon = NULL;
	wc.lpfnWndProc = (WNDPROC)proc;		//���ڻص�����
	wc.hInstance = (HINSTANCE)::GetModuleHandle(nullptr);		//ʵ�����
	wc.hCursor = ::LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = DEFAULT_WINDOW_CLASSNAME;
	if (!::RegisterClass(&wc))
	{
		DWORD dwError = GetLastError();
		printf("last error:%u\n", dwError);
		return nullptr;
	}
	DWORD dwStyle = WS_OVERLAPPEDWINDOW;
	//12����������
	HWND hWnd = ::CreateWindowEx(NULL, DEFAULT_WINDOW_CLASSNAME, szTitle,
		dwStyle, x, y, width, height, nullptr, NULL, wc.hInstance, nullptr);
	if (!hWnd)
	{
		return nullptr;
	}
	struct paper_window* window = (struct paper_window*)malloc(sizeof(struct paper_window));
	if (!window)
	{
		return nullptr;		//�ڴ治����
	}
	window->hWnd = hWnd;
	return window;
}


void paper_window_show(struct paper_window* window)
{
	::ShowWindow((HWND)window->hWnd, SW_SHOW);
}




